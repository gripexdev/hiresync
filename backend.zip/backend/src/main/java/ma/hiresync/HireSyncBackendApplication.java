package ma.hiresync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HireSyncBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HireSyncBackendApplication.class, args);
	}

}
